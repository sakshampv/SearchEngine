import java.util.*;
import java .io .*;
class PageEntry {
	PageIndex p;
	String pagename;

	PageEntry(String pageName) {
		pagename =pageName;
		System.out.println(stringer("stackmagazine"));
		PageIndex p = wordentries_producer(stringer(pageName));
	}

	String markremove (String a) {
		String ans = "";
		String[] pro = { "{" ,"}" ,"[" ,"]" ,"<" ,">" ,"=" ,"(" ,")" ,"." ,"," ,";" ,"'" ,"?" ,"#" ,"!" ,"-" ,":" };
 		for ( int i =0; i< a.length(); i++) {
			String x = a.substring(i,i+1);
			
			if (Arrays.asList(pro).contains(x) || a.charAt(i) == '"')
				ans = ans + " ";
			else 
				ans = ans + x.toLowerCase();
		}
		return ans;
	}

	ArrayList<String> stringer(String file_name){
		ArrayList<String> l1 = new ArrayList<String>();
 	try {
 		Scanner s = new Scanner (new FileInputStream ("webpages/"+file_name));
 		while (s. hasNextLine ()) {
 			String collect = markremove(s.nextLine());
 			String wer[] = collect.split("\\s");
 			//System.out.println(wer[0]);
 			for(int j = 0 ; j < wer.length ; j++) {
 				if (!wer[j].equals(""))
 					l1.add(wer[j]);
 			}
 		}
 	} catch ( FileNotFoundException e) {
 		System . out . println (" File not found ");
 	}
 	return l1;
	}

	PageIndex wordentries_producer(ArrayList<String> some){
		PageIndex p1 = new PageIndex();
		String connectors[] = {"a", "an", "the", "they", "these", "this", "for", "is", "are", "was", "of", "or", "and", "does", "will", "whose"};
		for (int x=0; x<some.size(); x++) {
			Position ps1 = new Position(this , x+1);
			String here = some.get(x);
			if (here.equals("stacks") || here.equals("structures") || here.equals("applications"))
            	here = here.substring(0, here.length() - 1);
			if (!Arrays.asList(connectors).contains(here))
				p1.addPositionForWord(here, ps1);
		}
		return p1;
	}
	PageIndex getPageIndex(){
		return p;	}

	public static void main (String[] args) {
		PageEntry p2 = new PageEntry("stackmagazine");
		//ArrayList<String> a1 =p2.stringer("stackmagazine");
		//System.out.println(a1);

		PageIndex li = p2.p;
		System.out.println(p2 == null);
		System.out.println(li == null);
		}
}