public class SearchEngine {
	InvertedPageIndex database;

	SearchEngine () {
		database = new InvertedPageIndex();
	}

	void performAction(String actionMessage) {
		String[] msg = actionMessage.split("\\s");
		if (msg[0].equals("addPage")) {
			PageEntry p1 = new PageEntry(msg[1]);
			database.addPage(p1);
		}
		else if (msg[0].equals("queryFindPagesWhichContainWord")) {
			MySet<PageEntry> srt = database.getPagesWhichContainWord(msg[1]);
			Node<PageEntry> itr = srt.head;
			String an = "";
			while(itr != null) {
				an = an + (itr.val.pagename) + ", ";
				itr = itr.next; 
			}
			if (an.equals(""))
				System.out.println("No webpage contains word " + msg[1]);
			else 
				System.out.println(an.substring(0,an.length() -2));
		}
		else if (msg[0].equals("queryFindPositionsOfWordInAPage")) {
			MyHashTable itrr = database.hashtable;
			int a = itrr.getHashIndex(msg[1]);
			MyLinkedList<WordEntry> p = database.hashtable.table[a];
			Node<WordEntry> nd = p.head;
			while(nd != null) {
				if(nd.val.word == msg[1])
					break;
			}
			if (database.page_database.IsMember(msg[2]))
				System.out.println("No webpage " + msg[2] + " found");
			else if (nd == null)
				System.out.println("Doesnt contain word in entire database");
			else {
				MyLinkedList<Position> pos = nd.val.indices;
				Node<Position> p1 = pos.head;
				String df ="";
				while(p1 != null) {
					if(p1.val.page.pagename == msg[2])
						df = df + p1.val.wordpos + ", ";
				}
				if(df.equals(""))
					System.out.println("Webpage "+ msg[2] +" does not contain word " + msg[1]);
				else 
					System.out.println(df.substring(0, df.length() -2));
			}
		}
	

	}

}