
class WordEntry {
	String word;
	MyLinkedList<Position> indices;

	WordEntry(String given_word) {
		word = given_word;
		indices = new MyLinkedList<Position>();
	}
	void addPosition(Position position) {
		indices.Insert(position);
	}
	void addPositions(MyLinkedList<Position> positions) {
		indices.Union(positions);
	}
	MyLinkedList<Position> getAllPositionsForThisWord() {
		return indices;
	}
	/*float getTermFrequency(String word) {
		
	}*/
}