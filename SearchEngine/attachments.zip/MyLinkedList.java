class Node<random> {
	Node<random> next =null;  
  	random val = null;
}
class MyLinkedList<random> {
	
	Node<random> head = null;

	public Boolean IsMember(random o) {
		Node<random> n = head;
		while (n != null) {
			if (n.val == o) {
				n = null;
				return true;
			}
			n = n.next;
		}
		return false;
		}
	public void Insert(random o) {
		Node<random> nm = new Node<random>();
		nm.val = o;
		Node<random> alpha = head;
		if (alpha == null){
			System.out.println("Hypereactive");
			head = nm;
		}
		else {
		while (alpha.next != null){
			alpha = alpha.next;
		}
		alpha.next = nm;
		}
	}
	public MyLinkedList<random> Union(MyLinkedList<random> a) {
		Node<random> head2 = a.head;
		Node<random> m1 = head;
		MyLinkedList<random> ans = a;
		for (int i = 0 ; m1 != null ; i++) {
			if (!a.IsMember(m1.val))
				ans.Insert(m1.val);
			m1 = m1.next;
		}
		return ans;
	}
	public MyLinkedList<random> Intersection(MyLinkedList<random> a) {
		Node<random> head2 = a.head;
		Node<random> m1 = head;
		Node<random> m2 = head2;
		MyLinkedList<random> ans = new MyLinkedList<random>();
		for (int i = 0 ; m1 != null ; i++) {
			for ( int j = 0 ; m2 != null ; j++) {
				if (m1.val == m2.val)
					ans.Insert(m1.val);
			}
			m2 = head2;
			m1 = m1.next;
		}
		return ans;
	}
}