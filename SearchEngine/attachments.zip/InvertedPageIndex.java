class InvertedPageIndex {
	MyHashTable hashtable;
	MyLinkedList<String> page_database = new MyLinkedList<String>();

	void addPage(PageEntry p) {
		MyLinkedList<WordEntry> tbe = p.p.wordentry_list;
		Node<WordEntry> itr = tbe.head;
		while(itr != null) {
			hashtable.addPositionsForWord(itr.val);
			itr = itr.next;
		}
		page_database.Insert(p.pagename);
	}
	MySet<PageEntry> getPagesWhichContainWord(String str) {
		int a =hashtable.getHashIndex(str);
		MyLinkedList<WordEntry> temp =hashtable.table[a];
		Node<WordEntry> itr = temp.head;
		while(itr != null) {
			if(itr.val.word == str)
				break;
		}
		MyLinkedList<Position> abc = itr.val.indices;
		Node<Position> itr2 = abc.head;
		Node<Position> itr3 = itr2.next; 
		MySet<PageEntry> ans = new MySet<PageEntry>();
		ans.Insert(itr2.val.getPageEntry());
		while( itr3 != null) {
			if(itr2.val.getWordIndex() != itr3.val.getWordIndex())
				ans.Insert(itr3.val.getPageEntry());
			itr2 = itr2.next;
			itr3 = itr3.next;
		}
		return ans;
	}
}