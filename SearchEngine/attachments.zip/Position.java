class Position {
	PageEntry page;
	int wordpos;

	Position(PageEntry p, int wordIndex) {
		page = p;
		wordpos = wordIndex;
	}
	PageEntry getPageEntry(){
		return page;
	} 
	int getWordIndex() {
		return wordpos;
	}
}