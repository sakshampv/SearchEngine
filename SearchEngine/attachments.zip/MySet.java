class Node<x> {
	Node<x> next =null;  
  	x val = null;
}

public class MySet<x> {

	Node<x> head = null;

	public Boolean IsMember(x o) {
		Node<x> n = head;
		while (n != null) {
			if (n.val == o) {
				n = null;
				return true;
			}
			n = n.next;
		}
		return false;
		}
	public void Insert(x o) {
		Node<x> nm = new Node<x>();
		nm.val = o;
		Node<x> alpha = head;
		if (alpha == null)
			head = nm;
		else {
		while (alpha.next != null){
			alpha = alpha.next;
		}
		alpha.next = nm;
		}
	}
	public MySet<x> Union(MySet<x> a) {
		Node<x> head2 = a.head;
		Node<x> m1 = head;
		MySet<x> ans = a;
		for (int i = 0 ; m1 != null ; i++) {
			if (!a.IsMember(m1.val))
				a.Insert(m1.val);
			m1 = m1.next;
		}
		return ans;
	}
	public MySet<x> Intersection(MySet<x> a) {
		Node<x> head2 = a.head;
		Node<x> m1 = head;
		Node<x> m2 = head2;
		MySet<x> ans = new MySet<x>();
		for (int i = 0 ; m1 != null ; i++) {
			for ( int j = 0 ; m2 != null ; j++) {
				if (m1.val == m2.val)
					ans.Insert(m1.val);
			}
			m2 = head2;
			m1 = m1.next;
		}
		return ans;
	}
	
}