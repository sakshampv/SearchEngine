class PageIndex {
	//PageEntry webpage;
	MyLinkedList<WordEntry> wordentry_list;

	PageIndex() {
		wordentry_list = new MyLinkedList<WordEntry>();
	}
	void addPositionForWord(String str, Position p){
		Node<WordEntry> temp = wordentry_list.head;
		Boolean contains = false;
		while (temp != null){
			if (temp.val.word == str){
				contains = contains || true;
				break;
				}
			temp = temp.next;
		}
		if (contains)
			temp.val.addPosition(p);
		else {
			System.out.println("else part");
			WordEntry b = new WordEntry(str);
			b.addPosition(p);
			wordentry_list.Insert(b);
			System.out.println(wordentry_list== null);
		}
	}
	MyLinkedList<WordEntry> getWordEntries(){
		return wordentry_list;
	}
}