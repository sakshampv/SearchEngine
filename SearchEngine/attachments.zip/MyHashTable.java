class MyHashTable {
	MyLinkedList<WordEntry>[] table;

	MyHashTable() {
		table = new MyLinkedList[1000];
	}

	int getHashIndex(String str){
		int hashVal = str.hashCode();
		hashVal %= 1000;
		if (hashVal < 0)
			hashVal = -(hashVal);
		return hashVal; 
	}
	void addPositionsForWord(WordEntry w){
		int er = getHashIndex(w.word);
		MyLinkedList<WordEntry> wordo = table[er];
		Node<WordEntry> itr = wordo.head;
		Boolean contains = false;
		while (itr != null){
			if (itr.val.word == w.word) {
				contains = true;
				break;
			}
			itr = itr.next;
		}
		if (contains)
			itr.val.indices.Union(w.indices);
		else {
			wordo.Insert(w);
		}
	}
}