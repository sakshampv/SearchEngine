public class AVLtree
{
 AVLNode root = new AVLNode() ;
 root = null;
 public AVLtree()
 {
     root = null;
 }

 public AVLtree(AVLNode a)
 {
     root = a;
 }

 public int isEmpty()
{
    if(root ==  null)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}

public int contains(int index)
{

    if (isEmpty())
    {
       return 0;
    } 
   else {
       if (root.position_entry.wordIndex == index) {
           return 1;
       } 
       else if (index < root.position_entry.wordIndex) {
           if(root.left == null)
           {
            return 0;
           }
           AVLTree x = new AVLTree(root.left);
           return x.contains(index);
       } 
       else {
        if(root.right == null)
        {
         return 0;
        }
           AVLTree x = new AVLTree(root.right);
           return x.contains(index);
       }
   }
    
}


public int isElement(Position p)
{
    if (isEmpty())
     {
        return 0;
    } 
    else {
        if (root.position_entry.wordIndex == position_entry.wordIndex) {
            return 1;
        } 
        else if (position_entry.wordIndex < root.position_entry.wordIndex) {
            if(root.left == null)
            {
             return 0;
            }
            AVLTree x = new AVLTree(root.left);
            return x.isElement(p);
        } 
        else {
            if(root.right == null)
            {
             return 0;
            }
            AVLTree x = new AVLTree(root.right);
            return x.isElement(p);
        }
    }
}

Position get(int i)
{
    AVLNode curr = new AVLNode();
    curr = this.root;
    while(true)
    {
       if(curr.left != null)
       {
           curr = curr.left;
       }
       else
       {
           break;
       }
    }
    // Now curr is lowest position
    
}

Position successor(AVLNode node)
{    AVLNode nn = new AVLNode();
    if(node.right != null)
    {
        
        nn = node.right;
        while(true)
        {
            if(nn.left != null)
            {
                nn = nn.left;
            }
            else
            {
                break;
            }
        }
        return nn.position_entry;
    }
    else
    {
        while(true)
        {
           nn=nn.parent;
        }
    }
}


}