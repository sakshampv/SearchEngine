public class tester
{

    public static void main(String args[])
    {
               MySet<Integer> set = new MySet<Integer>();
               set.addElement(10);
                 
    }
}