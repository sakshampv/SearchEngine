import java.util.ArrayList;

public class AVLtree {

    AVLNode root;

    public AVLtree() {
        root = null;
    }

    public AVLtree(AVLNode a) {
        root = a;
    }

    public boolean isEmpty() {
        return (root == null);
    }

    public int ht(AVLNode r) {
        if (r == null) {
            return 0;
        } else return r.height;
    }

    public AVLNode insert(Position p, AVLNode r) {
        if (r == null) {
            r = new AVLNode(p);
        } 
        else {
            if (p.newWordIndex < (r.position_entry.newWordIndex)) {
                r.left = insert(p, r.left);
                if (ht(r.left) - ht(r.right) == 2) {
                    if (p.newWordIndex < r.left.p.newWordIndex) {
                        r = lt_rot(r);
                    } else {
                        r.left = rt_rot(r.left);
                        r = lt_rot(r);
                    }
                }
            } 
            else if (p.newWordIndex > (r.p.newWordIndex)) {
                r.right = insert(p, r.right);
                if (ht(r.right) - ht(r.left) == 2) {
                    if (p.newWordIndex > r.right.p.newWordIndex) {
                        r = rt_rot(r);
                    } 
                    else {
                        r.right = lt_rot(r.right);
                        r = rt_rot(r);
                    }
                }
            }
        }
        r.ht = Integer.max(ht(r.right), ht(r.left)) + 1;
        return r;
    }

    public AVLNode lt_rot(AVLNode r) {
        AVLNode lch = r.left;
        r.left = lch.right;
        lch.right = r;
        r.ht = Integer.max(ht(r.left), ht(r.right)) + 1;
        lch.ht = Integer.max(ht(lch.left), ht(lch.right)) + 1;
        return lch;
    }

    public AVLNode rt_rot(AVLNode r) {
        AVLNode rch = r.right;
        r.right = rch.left;
        rch.left = r;
        r.ht = Integer.max(ht(r.left), ht(r.right)) + 1;
        rch.ht = Integer.max(ht(rch.left), ht(rch.right)) + 1;
        return rch;
    }

    public void insert(Position p) {
        if (search(p) == null) {
            this.root = this.insert(p, this.root);
        }
    }

    public AVLNode search(Position p) {
        if (isEmpty()) {
            return null;
        } 
        else {
            if (root.p.newWordIndex == p.newWordIndex) {
                return root;
            } 
            else if (p.newWordIndex < root.p.newWordIndex) {
                AVLtree x = new AVLtree(root.left);
                return x.search(p);
            } 
            else {
                AVLtree x = new AVLtree(root.right);
                return x.search(p);
            }
        }
    }

    public ArrayList<Position> traverse() {
        ArrayList<Position> travel = new ArrayList<Position>();
        if (this.isEmpty()) {
            return travel;
        }
        if (root.left == null && root.right == null) {
            travel.add(root.p);
        } 
        else {
            AVLtree lt_tree = new AVLtree(root.left);
            AVLtree rt_tree = new AVLtree(root.right);
            travel.addAll(lt_tree.traverse());
            travel.add(root.p);
            travel.addAll(rt_tree.traverse());
        }
        return travel;
    }

    public AVLNode max() {
        if (isEmpty()) {
            return root;
        } 
        else if (root.right == null) {
            return root;
        } 
        else {
            AVLtree ne = new AVLtree(root.right);
            return ne.max();
        }
    }

    public AVLNode min() {
        if (isEmpty()) {
            return root;
        } 
        else if (root.left == null) {
            return root;
        } 
        else {
            AVLtree ne = new AVLtree(root.left);
            return ne.min();
        }
    }

    public Position get(int i)
    {
        this.min()
    }

    public Position succ(int p) {
        ArrayList<Position> a = this.traverse();
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i).newWordIndex == (p)) {
                return a.get(i + 1);
            }
        }
        return null;
    }
}