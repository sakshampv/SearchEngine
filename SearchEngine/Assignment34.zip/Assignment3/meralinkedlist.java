public class AVLtree
{
    MyLinkedList<AVLNode> ll = new MyLinkedList<AVLNode>();

    public AVLtree()
    {
        ll = new MyLinkedList<AVLNode>();
    }

    public void insert(Position key)
    {
        AVLNode node = new AVLNode();
        node.position_entry = key;
        this.ll.insertAtEnd(node);
        return;
    }

    public Position get(int i)
    {
        Node<AVLNode> curr = new Node<AVLNode>();
        curr = this.ll.start;
        while((i--)!=0)
        {
            curr = curr.next;
        }
        return curr.data.position_entry;
    }

    public int contains(int index)
    {
        Node<AVLNode> curr = new Node<AVLNode>();
        curr = this.ll.start;
        while(curr!=null)
        {
            if(curr.data.position_entry.newWordIndex == index)
            {
                return 1;
            }
        }
        return 0;
    }

    public int isElement(Position p)
    {
        return this.contains(p.newWordIndex);
    }

    
}