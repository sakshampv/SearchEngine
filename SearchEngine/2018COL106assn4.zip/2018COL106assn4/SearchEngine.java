public class SearchEngine{

	public SearchEngine() {
		// ...
	}

	public void performAction(String actionMessage) {
		//....
	}
}
